import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.color.*;
import java.io.*;
import javax.imageio.*;
import java.util.Timer;
import java.util.TimerTask;

/**
Ball class for projectile motion game
@author David Lloyd-George
@version 05/29/2019
*/
public class Ball 
{
   /** conversion factor for millseconds to seconds */
   private static final double CONVERT_SEC = 1000;
   
   /** heigt of box */
   private static final double BOX_HEIGHT = 5; 
   
   /** gravitational acceleration(in m/s^2) */
   private static final double g = 9.8;
   
   /** default velocity of ball in m/s */
   public static final double DEFAULT_VELOCITY = 50;
   
   /** mass of ball in kg */
   private static final double MASS = 10;
   
   /** radius of ball */
   public static final int BALL_RADIUS = 15; 
   
   /** initial x position of ball */
   public static final double BALL_INTYPOS = 400;
   
   /** initial y position of ball */
   public static final double BALL_INTXPOS = 20;
   
   /** time delay in thread in milliseconds */
   private static final double TIME_DELAY = 10;
   
   /** initial angle of ball, in radians*/
   public static final double DEFAULT_ANGLE = .9;
   
   /** the value of air resistance of the ball*/
   private double airRes;
   
   /** the x coordinate of the ball in m*/
   private double Xpos; 
   
   /** the y coordinate of the ball in m*/
   private double Ypos;
   
   /** the initial velocity of the ball, in m/s */
   private double begVelocity;
   
   /** the initial angle of the ball */
   private double begAngle;
   
   /** Timer variable */
   private Timer myTimer;
   
   /** the time */
   private double time = 0;
   
   /** Shoot variable true if has been shot */
   private boolean Shoot;
   
   /** Xpos of the ball added to its radius */
   private double topX;
   
   /** Ypos of the ball added to its radius */
   private double topY;
   
   /** change in time of the timer */
   private double deltaT;
   
   /** x-velocity of ball */
   private double velocityX; 
   
   /** y-velocity of ball */
   private double velocityY;
   
   /** Box variable */
   private Box myBox;
   
   /** variable for whether ball has hit the ground
   true if it has */
   private boolean hitGround;
   
   /** boolean for if the ball has been reset */
   private boolean reset;
   
   /** boolean for if the ball is moving */
   private boolean isMoving;
   
   /** Forces variable for calculation of the ball trajectory */
   private Forces move;
   
   /**
   constructor
   */
   public Ball()
   {
      
      System.out.println("Ball Created");
      Xpos = BALL_INTXPOS; 
      Ypos = BALL_INTYPOS;
      begVelocity = DEFAULT_VELOCITY;
      begAngle = DEFAULT_ANGLE;
      
      
      deltaT = TIME_DELAY / CONVERT_SEC;
      Shoot = false;
      hitGround = false;
      airRes = -1;
      
      
   }

   
   
   
   
   
    
   
   
   /**
   resets the ball
   */
   public void reset()
   {
      this.setXpos((int) BALL_INTXPOS);
      this.setYpos((int) BALL_INTYPOS);
      hitGround = false;
      time = 0;
      
       
      setShoot(true);
      System.out.println(Shoot);
   }
   
   
   /**
   checks to see if ball has hit ground
   @return true if yes else false
   */
   public boolean hitGround()
   {
      if(Ypos >= 525)
      {
         return true;
      }
      else
      {
         return false;
      }
      
      
   }
   
   
   
    
    
         
   
   /**
   draws the ball
   @param g2 Graphics2D object
   */
   public void drawMe(Graphics2D g2)
   {
      double radius =  BALL_RADIUS;
      
      topX = Xpos - (radius);
      topY = Ypos - (radius);
      
      g2.fillOval((int) topX, (int) topY, BALL_RADIUS, BALL_RADIUS);
      g2.setColor(Color.cyan);
      
   }
   /**
   sets the value of shoot
   @param val the value shoot is to be set to
   */
   public void setShoot(boolean val)
   {
      Shoot = val;
   }
   
   /**
   returns the value of shoot
   @return the value of shoot
   */
   public boolean getShoot()
   {
      return Shoot;
   }
   
    /**
    returns the Ycoord of ball
    @return double the Ycoord of ball
    */
   public double getY()
   {
      return Ypos; 
   }
   
    /**
    returns the Xcoord of ball
    @return double the Xcoord of ball
    */
   public double getX()
   {
      return Xpos; 
   }
    
   /**
   returns the value of topY
   @return topY
   */
   public double getTopY()
   {
      return topY;
   }
   
   /**
   returns the value of topX
   @return topX
   */
   public double getTopX()
   {
      return topX;
   }
    /**
    returns air resistance value
    @return value for air resistance
    */
   public double getAirRes()
   {
      return airRes;
   }
    /**
    sets air resistance value
    @param r value for air resistance to be set to
    */
   public void setAirRes(double r)
   {
      airRes = r;
   }
   /*
   returns the ball's initial speed
   @return ball's initial speed
   */
   public double getBegVelocity()
   {
      return begVelocity;
   }
    /**
    sets the balls initial velocity
    @param vel velocity to be set to
    */
   public void setBegVelocity(double vel)
   {
      begVelocity = vel;
   }
   
   /*
   sets the initial angle of the ball
   @param agle the angle of the ball in degrees
   */
   public void setBegAngle(double agle)
   {
      begAngle = Math.toRadians(agle);
   }
   
   /**
   returns the begAngle
   @return begAngle
   */
   public double getBegAngle()
   {
      return begAngle;
   }
   
   /**
   sets the Xpos of ball
   @param x the xpos to be set
   */
   public void setXpos(double x)
   {
      Xpos = x;
   }
   
   /**
   sets the y pos of the ball
   @param y the ypos to be set 
   */
   public void setYpos(double y)
   {
      Ypos = y;
   }
   
   
   /**
   takes object and prints it out
   @return the string of object 
   */
   public String toString()
   {
      String val = "Xpos: " + this.getX() + "\n"+ "Ypos: " + this.getY() + "\n" + "airRes: " + this.getAirRes();
      return val;
   }
   
   /** 
   calls the forces class to calculate the motion of the ball
   @param b the value of air resistance to be used in calculation
   (-1 if no air Resistance)
   */
   public void animateBall(double b)
   {
         
      move = new Forces( this, b, MASS, begVelocity * Math.cos(begAngle), 
         begVelocity * Math.sin(begAngle), Xpos, Ypos);
      move.startThread();
         
      
   }
   
   
    /**
    returns the is moving variable
    @return isMoving
    */
   public boolean isMoving()
   {
      return isMoving;
   }
    
    /**
    sets the is moving variable
    @param b value to be set
    */
   public void setIsMoving(boolean b)
   {
      isMoving = b;
   }
   
    /**
    sets time
    @param t time to be set
    */
   public void setTime(double t)
   {
      time = t;
   }  
   
}