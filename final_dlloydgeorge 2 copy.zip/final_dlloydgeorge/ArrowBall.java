
import javax.swing.*;
import java.awt.geom.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.Point;

/**
class that creates the arrow that points in the direction of the 
velocity and angle of the ball
@author David Lloyd-George
@version 06/03/2019
*/
public class ArrowBall
{
   /** important angle used in calculation */
   private static final double ANGLE  = 60;
   
   /** factor used to get length of arrow */
   private static final double SCALING_FACTOR = 3;
   
   /** the starting position of the arrow */
   private int startX;
   
   /** the starting y-position of the arrow */
   private int startY;
   
   /** the angle of the arrow */
   private double Angle;
   
   /** the length of the arrow */
   private double Size;
   
   /** boolean value used to determine whether the arrow should 
   be drawn */
   private boolean val; 
   
   
   /**
   constructor
   @param x the x position that the arrow will be drawn from
   @param y the y position that the arrow will be drawn from
   @param agle the agle that the arrow will be drawn at (in radians)
   @param s the size of the arrow to be set
   */
   public ArrowBall(int x, int y, double agle, double s)
   {
      startX = x;
      startY = y;
      Angle = agle;
      Size = s;
      val = true;
   }
   
   /**
   draws the arrow
   @param g2 a Graphics2D object
   */
   public void drawMe(Graphics2D g2)
   {
      int endX = startX + (int) (Size * Math.cos(Angle));
      int endY = startY - (int) (Size * Math.sin(Angle));
      
      int arrowEndY =  endY + (int)((Size / SCALING_FACTOR) * Math.sin(Math.toRadians(ANGLE) - Angle));
      int arrowEndX =  endX + (int) ((Size / SCALING_FACTOR) * Math.cos(Math.toRadians(ANGLE)- Angle));
      
      int arrowEndX2 = endX - (int) ((Size / SCALING_FACTOR) * Math.sin(Angle - Math.toRadians(ANGLE)));
      int arrowEndY2 = endY - (int) ((Size / SCALING_FACTOR) * Math.cos(Angle - Math.toRadians(ANGLE)));
     
      if(val)
      {
         g2.drawLine(startX, startY, endX, endY);
          
      }
      
   }
   /**
   sets the angle of the arrow
   @param agle the angle to be set to (in radians)
   */
   public void setAngle(double agle)
   {
      Angle = agle;
   }
   
   /**
   sets the length of the ball
   @param s the length to be set to
   */
   public void setSize(double s)
   {
      Size = s;
   }
   /**
   sets the value of val
   @param v the value to set val to
   */
   public void setVal(boolean v)
   {
      val = v;
   }
}