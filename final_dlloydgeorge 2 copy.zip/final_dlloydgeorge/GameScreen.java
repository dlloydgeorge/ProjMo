import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.Canvas;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.event.*;
import java.awt.event.*;

/**
game screen used for game
@author David Lloyd-George
@version 06/02/2019
*/
public class GameScreen extends JPanel 
{
   /** ProjMoApp variable */
   private ProjMoApp myApp;
   
   /** variable for if the ball has been shot */
   private boolean beenShot = false; 
   
   /** variable for the control panel */
   private JPanel myControlPanel;
   
   /** variable for the label for speed */
   private JLabel mySpeedValLabel;
   
   /** JFrame variable */
   private JFrame frame;
   
   /** return button */
   private JButton myReturnButton;
   
   /** panel that game is in */
   private GamePanel myFieldPanel;
   
   /** Ball variable*/
   private Ball myBall; 
   
   /** run button */
   private JButton myRunButton;
   
   /** reset button */
   private JButton myResetButton;
   
   /** velocity slider */
   private JSlider myVelocitySlider;
   
   /** angle slider */
   private JSlider myAngleSlider;
   
   /** label for velocity */
   private JLabel VelocityLabel;
   
   /** label for velocity */
   private JLabel myVelocityLabel;
   
   /** Box variable */
   private Box myBox;
   
   /** ArrowBall variable */
   private ArrowBall myArrow;
   
   /** check box for air resistance */
   private JToggleButton myCheckBox;
   
   /**
   constructor
   @param app ProjMoApp object
   */
   public GameScreen(ProjMoApp app)
   {
      myApp = app;
      myBall = new Ball();
      myArrow = new ArrowBall((int) (myBall.BALL_INTXPOS - (myBall.BALL_RADIUS / 2)),
         (int) (myBall.BALL_INTYPOS - (myBall.BALL_RADIUS / 2)), myBall.getBegAngle(), 30);
      
      setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      
      myControlPanel = new JPanel();
      myControlPanel.setBackground(Color.RED);
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 1;
      gbc.weightx  = .1;
      gbc.weighty = .9;
      gbc.fill = GridBagConstraints.BOTH;
      add(myControlPanel, gbc);
      
      myFieldPanel = new GamePanel(myBall, myArrow);
      gbc.gridx = 1;
      gbc.gridy = 1;
      gbc.gridwidth = 1;
      gbc.weightx = .9;
      gbc.weighty = .9;
      gbc.fill = GridBagConstraints.BOTH;
      add(myFieldPanel, gbc);
      
      JLabel myTitle = new JLabel("ProjMo");
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.gridwidth = 2;
      gbc.weighty = .1;
      add(myTitle, gbc);
      
      myFieldPanel.requestFocusInWindow();
      requestFocusInWindow();
      
   }
   
   /** 
   sets up control panel of game screen
   */
   public void setUpControlPanel()
   {
      myControlPanel.setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      
      myRunButton = new JButton("Shoot");
      gbc.gridx = 0;
      gbc.gridy = 3;
      gbc.gridwidth = 0;
      //gbc.weighty =.1;
      myControlPanel.add(myRunButton, gbc);
      myRunButton.addActionListener(new ShootListener());
      
      myReturnButton = new JButton("Back");
      gbc.gridx = 0;
      gbc.gridy = 4;
      gbc.gridwidth = 0;
      //gbc.weighty = .1;
      myControlPanel.add(myReturnButton, gbc);
      myReturnButton.addActionListener(new RunListener());
      
      myResetButton = new JButton("Reset");
      gbc.gridx = 0;
      gbc.gridy = 5;
      gbc.gridwidth = 0;
      myControlPanel.add(myResetButton, gbc);
      myResetButton.addActionListener(new ResetListener());
      
      myVelocitySlider = new JSlider(0, 100, 
         (int) myBall.DEFAULT_VELOCITY);
      myVelocitySlider.setMajorTickSpacing(1);
      myVelocitySlider.setPaintTicks(true);
      myVelocitySlider.setSnapToTicks(true);   
      myVelocitySlider.setLabelTable(myVelocitySlider.createStandardLabels(10));
      myVelocitySlider.setPaintLabels(true);
      myVelocitySlider.setOrientation(JSlider.VERTICAL);
      myVelocitySlider.addChangeListener(new SliderListener());
      
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 3;
      gbc.weightx = .33;
      gbc.weighty = .1;
      myControlPanel.add(myVelocitySlider, gbc);
      
      // JLabel VelocityLabel = new JLabel("Speed");
      // gbc.gridx = 0;
      // gbc.gridy = 0;
      // gbc.gridwidth = 0;
      // gbc.weightx = 0;
      // gbc.weighty = .1;
      // myControlPanel.add(VelocityLabel, gbc);
      
      myAngleSlider = new JSlider(JSlider.VERTICAL,0, 90, (int) Math.toDegrees(myBall.DEFAULT_ANGLE));
      myAngleSlider.setMajorTickSpacing(1);
      myAngleSlider.setPaintTicks(true);
      myAngleSlider.setSnapToTicks(true);   
      myAngleSlider.setLabelTable(myAngleSlider.createStandardLabels(10));
      myAngleSlider.setPaintLabels(true);
      myAngleSlider.setOrientation(JSlider.VERTICAL);
      myAngleSlider.addChangeListener(new AngleSliderListener());
      gbc.gridx = 3;
      gbc.gridy = 1;
      gbc.gridwidth = 3;
      gbc.weightx = 1;
      gbc.weighty = .1;
      myControlPanel.add(myAngleSlider, gbc);
      
      myCheckBox = new JToggleButton("air res", false);
      myCheckBox.addItemListener(new AirResistanceListener());
      gbc.gridx = 3;
      gbc.gridy = 7;
      gbc.gridwidth = 2;
      myControlPanel.add(myCheckBox, gbc);
   
   }
   
   
   
   /**
   action listener for back button
   */
   private class RunListener implements ActionListener
   {
      /** 
      runs when the back button is pressed
      @param e action of pressing button
      */
      public void actionPerformed(ActionEvent e)
      {
         
         myApp.switchScreen("Title");
         
      }
      
   }
   
   /**
   change listener for the velocity slider
   */
   private class SliderListener implements ChangeListener
   {
      /**
      runs when the velocity slider is changed
      @param e action of moving slider
      */
      public void stateChanged(ChangeEvent e)
      {
         if(!beenShot)
         {  
            myBall.setBegVelocity(myVelocitySlider.getValue());
            double vel = myBall.getBegVelocity();
            myArrow.setSize(vel * .5);
            myVelocitySlider.setValue((int) vel);
            
            myVelocityLabel.setText("" + myVelocitySlider.getValue());
         }
         
         else
         {
            
         }
      }
      
   }
   
   
   
   /**
   change listener class for the angle slider
   */
   private class AngleSliderListener implements ChangeListener
   {
      /**
      runs when the angle slider is moved
      @param e action of moving slider
      */
      public void stateChanged(ChangeEvent e)
      {
         if(!beenShot)
         {  
            myBall.setBegAngle(myAngleSlider.getValue());
            double val = Math.toDegrees(myBall.getBegAngle());
            double val2 = myBall.getBegAngle();
            myAngleSlider.setValue( (int) val);
            myArrow.setAngle(val2);
            myFieldPanel.repaint();
            
            GameScreen.this.requestFocusInWindow();
         }
         
         else
         {
            
         }
         
      }
   }
   /**
   action listener class for the shoot button
   */
   private class ShootListener implements ActionListener
   {
      /**
      method that shoots ball
      @param e the action of pressing the shoot button
      */
      public void actionPerformed(ActionEvent e)
      {
         myBall.setShoot(true);
         myBall.animateBall(myBall.getAirRes());
         beenShot = true;
         myArrow.setVal(false);
         
      }
   
   
   
   }
   /**
   action listener class for the reset button
   */
   private class ResetListener implements ActionListener
   {
      /**
      method that resets game when reset button is pressed
      @param e the action of pressing the reset button
      */
      public void actionPerformed(ActionEvent e)
      {
         if(myBall.hitGround() || myFieldPanel.inBox())
         {
            myBall.reset();
            myFieldPanel.reset();
            myFieldPanel.repaint();
            beenShot = false;
            myArrow.setVal(true);
         }
      }
      
   }
   
   /**
   class for handling the air resistance switch
   */
   private class AirResistanceListener implements ItemListener
   {
      /**
      method that switches air resistance on and off in game
      @param itemEvent ItemEvent
      */
      public void itemStateChanged(ItemEvent itemEvent) 
      {
         if(!beenShot)
         {
            int state = itemEvent.getStateChange();
            if(state == ItemEvent.SELECTED)
            {
               myBall.setAirRes(.05);
            }
            else if(state == ItemEvent.DESELECTED)
            {
               myBall.setAirRes(-1);
               System.out.println(myBall.getAirRes());
            }
         
         }
      }
   }
   
   
   
   
   
   

   
   
}