import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.Canvas;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.event.*;
import java.awt.event.*;

/**
creates a the win popup widget
@author David Lloyd-George
@version 06/02/2019
*/
public class WinScreen
{
   /** width of pop up */
   private static final int POP_WIDTH = 350;
   
   /** height of pop up */
   private static final int POP_HEIGHT = 190;
   
   /** x-pos of pop up */
   private static final int POP_X = 300;
   
   /** y-pos of pop up */
   private static final int POP_Y = 250;
    
   /** variable for the pop up */
   private Popup myWinPopUp;
   
   /** PopupFactory label */
   private PopupFactory p;
   
   /* variable for ok button */
   private JButton okButton;
   
   /** variable for panel that goes in the pop up */
   private JPanel myWinPanel;
   
   /** ProjMoApp variable*/
   private ProjMoApp myApp;
   
   
   /**
   constructor
   @param app ProjMoApp object
   */
   public WinScreen(ProjMoApp app)
   {
      myApp = app;
      p = new PopupFactory();
      
      JLabel label = new JLabel(" You Won!");
      okButton = new JButton("OK");
      
      okButton.addActionListener(new ButtonListener());   
      
      try
      {
      
      }
      
      catch(Exception e)
      {
      
      }
      
      myWinPanel = new JPanel();
      
      myWinPanel.setBackground(Color.blue);
      myWinPanel.setPreferredSize(new Dimension(POP_WIDTH, POP_HEIGHT));
      myWinPanel.add(label);
      myWinPanel.add(okButton);
      
      myWinPopUp = p.getPopup(myApp.getFrame(), myWinPanel, POP_X, POP_Y);
      myWinPopUp.show();
      
   }
   
   
   
   /**
   class for handling the button on the win pop up
   */
   private class ButtonListener implements ActionListener
   {
      /**
      performs actions on pop up, either closing it if the ok button is hit 
      or else doing nothing
      @param e ActionEvent object
      */
      public void actionPerformed(ActionEvent e)
      {
         if(e.getActionCommand().equals("OK"))
         {
            myWinPopUp.hide();
            
            myWinPopUp = p.getPopup(myApp.getFrame(), myWinPanel, POP_X, POP_Y);
            
         }
         else 
         {
            myWinPopUp.show();
         }
      }
   }
   
   
}