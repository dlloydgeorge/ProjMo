import javax.swing.*;
import java.awt.geom.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.Point;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;

/** 
class that contains the panel where the game runs
@author David Lloyd-George
@version 06/02/2019
*/
public class GamePanel extends JPanel
{
   /** y-pos of starting box */
   private static final int STARTBOX_Y = 420;
   
   /** width of starting box */
   private static final int STARTBOX_WIDTH = 20;
   
   /** height of starting box */
   private static final int STARTBOX_HEIGHT = 105;
   
   /** value of y-pos at floor */
   private static final int FLOOR_VAL1 = 525;
   
   /** second value of y-pos at floor */
   private static final int FLOOR_VAL2 = 520;
   
   /** Ball variable */
   private Ball myBall;
   
   /** WinScreen variable */
   private WinScreen myWinScreen;
   
   /** loseScreen variable*/
   private LoseScreen myLoseScreen;
   
   /** ProjMoApp variable */
   private ProjMoApp myApp;
   
   /** myBox Variable */
   private Box myBox;
   
   
   /** GameScreen variable */
   private GameScreen myGameScreen;
   
   /** ArrowBall object */
   private ArrowBall myArrow;
   
   //private Box myBox;
   
   /** boolean variable used in the Thread */
   private boolean val;
   
   /** background image */
   private BufferedImage backGroundImage;
   
   /**
   constructor for GamePanel
   @param b Ball object
   @param bi ArrowBall object
   */
   public GamePanel(Ball b, ArrowBall bi)
   {
      
      super();
      
      myBox = new Box();
      myBall = b;
      myApp = new ProjMoApp();
      myArrow = bi;
      val = true;
      
      try
      {
         InputStream is = getClass().getResourceAsStream("background.png");
         backGroundImage = ImageIO.read(is);
      }
      catch(IOException ioe)
      {
      
      }
      
      GameUpdater updater = new GameUpdater();
      updater.start();
      
   }
   
   
   
   /*
   paints the game panel
   @param g Graphics object
   */
   public void paintComponent(Graphics g)
   {
      Graphics2D g2 = (Graphics2D) g; 
      
      g2.drawImage(backGroundImage, 0, 0, null); 
      
      myArrow.drawMe(g2);
      
      myBall.drawMe(g2);
      
      
      g2.fillRect(0, STARTBOX_Y, STARTBOX_WIDTH, STARTBOX_HEIGHT);
      myBox.drawMe(g2);
      
      
      
      
      
      
   
   
      
   }
   
   /**
   sets val 
   @param v the boolean value that val is to be assigned
   */
   public void setVal(boolean v)
   {
      val = v;
   }
   
   /**
   checks to see if ball is in box
   @return true if in box else false
   */
   public boolean inBox()
   {
      if(myBall.getY() >= myBox.getY() && myBall.getTopX() > myBox.getX() + 5 && myBall.getTopX() < myBox.getX() + 55)
      {
         return true;
      } 
      else
      {
         return false;
      }
   }
   /**
   checks to see if ball has hit bottom of box
   @return true if ball has hit box bottom else false
   */
   public boolean hitBoxBottom()
   {
      if(inBox() && myBall.getY() >= FLOOR_VAL2)
      {
         return true;
      }
      
      else
      {
         return false;
      }
   }
   
   /**
   checks to see if ball has hit ground
   @return true if ball has hit ground else false
   */
   public boolean hitGround()
   {
      if(myBall.getY() >= FLOOR_VAL1)
      {
         return true;
      }
      
      else
      {
         return false;
      }
   }
   
   /**
   resets val 
   */
   public void reset()
   {
      val = true;
      GameUpdater updater = new GameUpdater();
      updater.start();
   }
   
   /**
   repaints screen class
   */
   private class GameUpdater extends Thread
   {
      /**
      method that runs in thread
      */
      public void run()
      {
         
         //boolean triggeredScreen = false;
         while(val)
         {
            repaint();
            //System.out.println("we painting");
            if(inBox())
            {
               
               if(hitBoxBottom())
               {  
                  System.out.println("in Box");
                  myWinScreen = new WinScreen(myApp);
                  
                  val = false;
                  
                  
               }
               
               else
               {
                  
               }
               
            }
            
            else if(myBall.hitGround())
            {
               System.out.println("Hit Ground");
               myLoseScreen = new LoseScreen(myApp);
               
               val = false;
               
            }
            
            
            
            try
            {
               sleep(1);
            }
            catch(InterruptedException ie)
            {
               
            }
            
         }
      }
   
   }



   
   
   
   
   
   
   
}