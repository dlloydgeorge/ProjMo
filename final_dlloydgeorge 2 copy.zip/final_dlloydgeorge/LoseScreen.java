import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.Canvas;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.event.*;
import java.awt.event.*;

/**
class for the lose pop up
@author David Lloyd-George
@version 06/02/2019
*/
public class LoseScreen
{

   /** width of pop up */
   private static final int POP_WIDTH = 350;
   
   /** height of pop up */
   private static final int POP_HEIGHT = 190;
   
   /** x-pos of pop up */
   private static final int POP_X = 300;
   
   /** y-pos of pop up */
   private static final int POP_Y = 250;
   
   /**Popup to be made */
   private Popup myLosePopUp;
   
   /** PopupFactory variable */
   private PopupFactory p;
   
   /** Button in popup */
   private JButton tryagainButton; 
  
   /** Jpanel to go inside popup */
   private JPanel myLosePanel;
   
   /** ProjMoApp variable */
   private ProjMoApp myApp;
   
   /**
   constructor
   @param app ProjMoApp object
   */
   public LoseScreen(ProjMoApp app)
   {
      myApp = app;
      p = new PopupFactory();
      JLabel label = new JLabel("You Lost");
      
      
      tryagainButton = new JButton("try again");
      tryagainButton.addActionListener(new TryButtonListener());
      try
      {
      
      }
      
      catch(Exception e)
      {
      
      }
      myLosePanel = new JPanel();
      myLosePanel.setPreferredSize(new Dimension(POP_WIDTH, POP_HEIGHT));
      myLosePanel.setBackground(Color.red);
      myLosePanel.add(label);
      myLosePanel.add(tryagainButton);
      
      
      
      myLosePopUp = p.getPopup(myApp.getFrame(), myLosePanel, POP_X, POP_Y);
      myLosePopUp.show();
      
       
   }
    
   
   /**
   class for pressing button
   */
   private class TryButtonListener implements ActionListener
   {
      /** 
      performs action if button is pressed
      @param e ActionEvent object
      */
      public void actionPerformed(ActionEvent e)
      {
         if(e.getActionCommand().equals("try again"))
         {
            myLosePopUp.hide();
            
            myLosePopUp = p.getPopup(myApp.getFrame(), myLosePanel, POP_X, POP_Y);
            
         }
         else 
         {
            myLosePopUp.show();
         }
      }
   }
   
}


