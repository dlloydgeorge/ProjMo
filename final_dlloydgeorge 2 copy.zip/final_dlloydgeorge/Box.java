import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.color.*;
import java.io.*;
import javax.imageio.*;
import java.util.Timer;
import java.util.TimerTask;

/** 
class that generates a box in game
@author David Lloyd-George
@verison 06/03/2019
*/
public class Box
{
   /** width of box*/
   public static final int BOX_WIDTH = 5;
   
   /** width of box */
   public static final int BOX_WIDTH2 = 55;
   
   /** height of box */
   public static final int BOX_HEIGHT = 20;
   
   /** 2nd height of box */
   public static final int BOX_HEIGHT2 = 25;
   
   /** x-position of box */
   private int Xpos;
   
   /** y-position of box */
   private int Ypos; 
   
   /** 
   default constructor
   */
   public Box()
   {
      Xpos = 50 + (int)(Math.random() * 300);
      
      Ypos =  500;
      
   }
   
   /**
   constructor
   @param x value of x to be set
   @param y value of y to be set
   */
   public Box(int x, int y)
   {
      Xpos = x;
      Ypos = y;
   }
   
   /** 
   draws the box
   @param g2 Graphics object
   */
   public void drawMe(Graphics g2)
   {
      g2.setColor(Color.white);
      g2.fillRect(Xpos, Ypos, BOX_WIDTH, BOX_HEIGHT2);
      g2.fillRect(Xpos + BOX_WIDTH, Ypos + BOX_HEIGHT, 50, BOX_WIDTH);
      g2.fillRect(Xpos + BOX_WIDTH2, Ypos, BOX_WIDTH, BOX_HEIGHT2);
      
   }
   
   /**
   returns y-pos of box
   @return y-pos of box
   */
   public int getY()
   {
      return Ypos;
   }
   
   /**
   returns x-pos of box
   @return x-pos of box
   */
   public int getX()
   {
      return Xpos;
   }
   
   
} 