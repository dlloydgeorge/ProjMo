import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

/**
TitleScreen class that sets up the title screen of game
@author David Lloyd-George
@version 06/02/2019
*/
public class TitleScreen extends JPanel
{
   /** the width of the button */
   public static final int BUTTON_WIDTH = 200;
   
   /** the height of the button */
   public static final int BUTTON_HEIGHT = 50;
   
   /** height of screen */
   private static final int SCREEN_WIDTH = 800;
   
   /** width of screen */
   private static final int SCREEN_HEIGHT = 600;
   
   /** moves button by this factor */
   private static final int MOVE_FACTOR  = 100;
   
   /** ProjMoApp variable*/
   private ProjMoApp myApp; 
   
   /** variable that sets up the startbutton graphics */
   private Rectangle2D.Double startButton;
   
   /** variable for about button drawing */
   private Rectangle2D.Double aboutButton;
   
   /** variable to draw rectangle in background */
   private Rectangle2D.Double background;
   
   /**
   constructor 
   @param app ProjMoApp object
   */
   public TitleScreen(ProjMoApp app)
   {
      myApp = app;
      addMouseListener(new MyButtonListener());
   }
   
   /**
   sets up graphics for title screen
   @param g Graphics  object
   */
   public void paintComponent(Graphics g)
   {
      Graphics2D g2 = (Graphics2D) g;
      
      background = new Rectangle2D.Double(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
      g2.setColor(Color.CYAN);
      g2.fill(background);
      
      g2.setColor(Color.black);
      int buttonX = (SCREEN_WIDTH / 2) - (BUTTON_WIDTH / 2) - MOVE_FACTOR;
      int buttonY = (SCREEN_HEIGHT / 2) - (BUTTON_HEIGHT / 2);
      
      startButton = new Rectangle2D.Double(buttonX, buttonY, 
         BUTTON_WIDTH, BUTTON_HEIGHT);
      g2.draw(startButton);
      g2.setFont(new Font("Arial", Font.BOLD, 18));
      g2.drawString("Play Game", buttonX + 75, buttonY + 30);
      
      g2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 48));
      g2.drawString("ProjMo", 325, 250);
      
      aboutButton = new Rectangle2D.Double(500, 275, BUTTON_WIDTH, BUTTON_HEIGHT);
      g2.draw(aboutButton);
      g2.setFont(new Font("Arial", Font.BOLD, 18));
      g2.drawString("About", 575, 305);
      
      
   }
   /**
   class that sets up buttons to be pressed
   */
   private class MyButtonListener implements MouseListener
   {
      /**
      switches screens depending on which button is pressed
      @param e MouseEvent object
      */
      public void mousePressed(MouseEvent e)
      {
         int mouseX = e.getX();
         int mouseY = e.getY();
         
         if(startButton.contains(mouseX, mouseY))
         {
            myApp.switchScreen(ProjMoApp.GAME);
         }
         else if(aboutButton.contains(mouseX, mouseY))
         {
            myApp.switchScreen(ProjMoApp.ABOUT);
         }
      }
      
      /** 
      method for when mouse is released
      @param e MouseEvent object
      */
      public void mouseReleased(MouseEvent e)
      {
      
      }
      
      /** 
      method for when mouse is clicked
      @param e MouseEvent object
      */
      public void mouseClicked(MouseEvent e)
      {
      
      }
      
      /** 
      method for when mouse is entered
      @param e MouseEvent object
      */
      public void mouseEntered(MouseEvent e)
      {
      
      }
      
      /** 
      method for when mouse is exited
      @param e MouseEvent object
      */
      public void mouseExited(MouseEvent e)
      {
      
      }
   
   }
   
}