import java.util.Timer;
import java.util.TimerTask;

/**
calculates the forces for the ball;
@author David Lloyd-George
@version 06/02/2019
*/
public class Forces
{
   
   /** gravity */
   public static final double g = 9.8;
   
   /** value for calculation of motion */
   public static final double VAL = .5;
   
   /** time delay in thread in milliseconds*/
   public static final double TIME_DELAY = 10;
   
   /** conversion factor for converting milliseconds to seconds */
   public static final double CONVERT_SEC = 1000;
   
   /** constant for runge-kutta */
   public static final double RUNGE_CONST = 6; 
   
   /** acceleration variable*/
   private double acceleration;
   
   /** change in time in seconds */
   private double deltaT;
   
   /** mass of ball */
   private double mass;
   
   /** runge kutta variable */
   private double K_1;
   
   /** runge kutta variable */
   private double K_2;
   
   /** runge kutta variable */
   private double K_3;
   
   /** runge kutta variable */
   private double K_4;
   
   /** runge kutta variable for y runge kutta*/
   private double K_1Y;
   
   /** runge kutta variable for y runge kutta*/
   private double K_2Y;
   
   /** runge kutta variable for y runge kutta*/
   private double K_3Y;
   
   /** runge kutta variable for y runge kutta*/
   private double K_4Y;
   
   /** value of air resistance */
   private double airRes;
   
   /** x-speed of ball */
   private double speedX;
   
   /** x-speed of ball */
   private double speedY;
   
   /** x-position of ball */
   private double posX;
   
   /** y-position of ball */
   private double posY;
   
   /** Ball variable */
   private Ball myBall;
   
   /** time in thread (used for projectile motion 
   without air resistance calculation) */
   private double time;
   
   /* 
   constructive boi
   @param a parameter for air Resistance;
   @param m the parameter for mass of ball;
   @param vx the value of the x-velocity
   @param vy the value of the y-velocity 
   @param px the x-pos of the ball
   @param py the y-pos of ball
   */
   public Forces(Ball ba, double b, double m, double vx, double vy, double px, double py)
   {
       myBall = ba;
       airRes = b;
       mass = m;
       speedX = vx;
       speedY = -vy;
       posX = px;
       posY = py;
       deltaT = TIME_DELAY / CONVERT_SEC;
   }
   
   /**
   finds the x-acceleration of the ball
   @param v velocity of the ball
   @return the x-acceleration of the ball
   */
   public double findAccelX(double v)
   {     
         return (- airRes * Math.abs(v) * v) / mass;     
   }
   
   /**
   finds the y-acceleration of the ball
   @param v the velocity of the ball at some instant
   @return the y-acceleration of the ball
   */
   public double findAccelY(double v)
   {
      return  (-(airRes * Math.abs(v) * v) + (mass * g)) / mass;
   }
   
   /**
   starts the thread that calculates position
   */
   public void startThread()
   {
      findPos p = new findPos();
      p.start();
      
   }
   
   /**
   finds the approximate value of the X-velocity of the ball using the 
   runge kutta algorithm from a given velocity
   @param v the intial velocity of the ball at some instant
   @return the new velocity of the ball
   */
   public double rungeKuttaX(double v)
   {
      K_1 = deltaT * findAccelX(v); 
      K_2 = deltaT * findAccelX(v + (K_1 / 2));
      K_3 = deltaT * findAccelX(v + (K_2 / 2));
      K_4 = deltaT * findAccelX(v + K_3);
      
      return ((K_1 + (2 * K_2) + (2 * K_3) + K_4) / RUNGE_CONST); 
      
   }
   
   /**
   finds the change in y-velocity of the ball using the 
   Runge-Kutta algorithm
   @param v the y-velocity of the ball
   @return the change in y-velocity
   */
   public double rungeKuttaY(double v)
   {
      K_1Y = deltaT * findAccelY(v); 
      K_2Y = deltaT * findAccelY(v + (K_1Y / 2));
      K_3Y = deltaT * findAccelY(v + (K_2Y / 2));
      K_4Y = deltaT * findAccelY(v + K_3Y);
      
      return  ((K_1Y + (2 * K_2Y) + (2 * K_3Y) + K_4Y) / RUNGE_CONST);
   }
   
   /**
   finds the change in the X position of the ball
   @param v the x-velocity of the ball
   @return the change in X 
   */
   public double getDeltaX(double v)
   {
      return (v * deltaT);
   }
   
   /**
   finds the change in Y position of the ball
   @param v the y-velocity of the ball
   @return the change in Y
   */
   public double getDeltaY(double v)
   {
      return (v * deltaT);
   }
   
   /**
   returns the x-pos of ball
   @return x-pos
   */
   public double getX()
   {
      return posX;
   }
   /**
   returns the y-pos of ball
   @return the y-pos of ball
   */
   public double getY()
   {
      return posY;
   }
   
   /** 
   sets the value of air resistance
   @param a the value of air resistance to be set to
   */
   public void setAirRes(double a)
   {
      airRes = a;
   }
   /**
   performs calculation for projectiles without air resistance
   */
   public void moveBall()
   {
      posX = myBall.BALL_INTXPOS + speedX * time; 
        
      posY = myBall.BALL_INTYPOS + (speedY * time) + (VAL * g * time * time);
   }
   
 
   /**
   thread that performs calculations for position of ball
   */
   private class findPos extends Thread
   {
      /**
      runs the algorithm calculation
      */
      public void run()
      {
         try
         {
            while(!myBall.hitGround())
            {
                if( airRes == -1)
                {
                    moveBall();
                    
                    time += TIME_DELAY / CONVERT_SEC;
                }
                
                else if(airRes > 0)
                {
                
                  double ax = findAccelX(speedX);
                  double ay = findAccelY(speedY);
                
                  speedX += rungeKuttaX(speedX);
                  speedY += rungeKuttaY(speedY);
                  System.out.println(speedY);
                  posX += getDeltaX(speedX);
                  posY += getDeltaY(speedY);
                  
                  
                }
                myBall.setXpos(posX);
                myBall.setYpos(posY);
                sleep((int) TIME_DELAY);
                
            }
         }
         catch(Exception e)
         {
            
         }
      }
   
   }
   
   
   
   
}