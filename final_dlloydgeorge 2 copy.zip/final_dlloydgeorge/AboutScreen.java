
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.Canvas;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;


/**
class for about screen in game
@author David Lloyd-George
@version 05/29/2019
*/
public class AboutScreen extends JPanel
{
   /** ProjMoApp variable */
   private ProjMoApp myApp;
   
   /** size of font */
   private static final int FONT_SIZE = 18;
   
   /** moves string to desired location in button */
   private static final int MOVE_STRING = 30;
   
   /** x-pos of button */
   private static final int BUTTONX = 50;
   
   /** y-pos of button */
   private static final int BUTTONY = 500; 
   
   /** width of button */
   private static final int BUTTON_WIDTH = 100;
   
   /** height of button */
   private static final int BUTTON_HEIGHT = 50;
   
   /** Rectangle variable for return button */
   private Rectangle2D.Double myReturnButton;
   
   /** BufferedImage Variable */
   private BufferedImage myImage;
   
   /** rectangle for background painting */
   private Rectangle2D.Double myBackGround;
   
   /**
   constructor
   @param app ProjMoApp object
   */
   public AboutScreen(ProjMoApp app)
   {
      myApp = app;
      
      addMouseListener(new backButton());
      try
      {
         InputStream is = getClass().getResourceAsStream("AboutInfo.png");
         myImage = ImageIO.read(is);
      }
      catch(IOException ioe)
      {
         
      }
   }
   
   /**
   paints the about screen
   @param g Graphics object
   */
   public void paintComponent(Graphics g)
   {
      Graphics2D g2 = (Graphics2D) g;
      
      
      g2.drawImage(myImage, 0, 0, null);
      myReturnButton = new Rectangle2D.Double(BUTTONX, BUTTONY, BUTTON_WIDTH, BUTTON_HEIGHT);
      g2.setColor(Color.black);
      g2.draw(myReturnButton);
      g2.setFont(new Font("Arial", Font.BOLD, FONT_SIZE));
      g2.drawString("Back", BUTTONX + MOVE_STRING, BUTTONY + MOVE_STRING);
      
      
      
      
   }
   
   
   /** 
   class that handles the mouse pressing the button
   */
   private class backButton implements MouseListener
   {
      /** 
      method for when mouse is pressed
      @param e MouseEvent object
      */
      public void mousePressed(MouseEvent e)
      {
         int mouseX = e.getX();
         int mouseY = e.getY();
         if(myReturnButton.contains(mouseX, mouseY))
         {
            myApp.switchScreen(ProjMoApp.TITLE);
            
         }
         
         else
         {
         
         }
      }
      
      /** 
      method for when mouse is released
      @param e MouseEvent object
      */
      public void mouseReleased(MouseEvent e)
      {
      
      }
      
      /** 
      method for when mouse is clicked
      @param e MouseEvent object
      */
      public void mouseClicked(MouseEvent e)
      {
      
      }
      
      /** 
      method for when mouse is entered
      @param e MouseEvent object
      */
      public void mouseEntered(MouseEvent e)
      {
      
      }
      
      /** 
      method for when mouse is exited
      @param e MouseEvent object
      */
      public void mouseExited(MouseEvent e)
      {
      
      }
   }
   
   
}