import java.awt.*;
import javax.swing.*;

/**
class that runs the game
@author David Lloyd-George
@version 06/03/2019
*/
public class ProjMoApp
{  
   /** name used for title screen */
   public static final String TITLE = "Title";
   
   /** name used for game screen */
   public static final String GAME = "Game";
   
   /** name used for about screen */
   public static final String ABOUT = "About";
   
   /** height of screen */
   private static final int SCREEN_WIDTH = 800;
   
   /** width of screen */
   private static final int SCREEN_HEIGHT = 600;
   
   /* JFrame variable for myApp*/
   private JFrame myApp;
   
   /** GameScreen variable to set up the game screen*/
   private GameScreen gScreen;
   
   /** variable to set up the title screen*/
   private TitleScreen tScreen;
   
   /** AboutScreen variable */
   private AboutScreen aScreen;
   
   /*variable that holds all the screen objects*/
   private JPanel myGenPanel;
   
   
   
   
   /* 
   default constructor
   */
   public ProjMoApp()
   {
      
   }
   
   /*
   sets up frame of the game
   */
   public void setUpFrame()
   {
      myApp = new JFrame("ProjMo");
      myApp.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
      myApp.setResizable(false);
      
      aScreen = new AboutScreen(this);
      tScreen = new TitleScreen(this);
      gScreen = new GameScreen(this);
      gScreen.setUpControlPanel();
      myGenPanel = new JPanel(new CardLayout());
      myGenPanel.add(tScreen, TITLE);
      myGenPanel.add(aScreen, ABOUT);
      myGenPanel.add(gScreen, GAME);
      
      myApp.add(myGenPanel);
      myApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      myApp.setVisible(true);
   }
   
   /* 
   run method for game
   */
   public void run()
   {
      setUpFrame();
      
   }
   
   
   /** 
   returns the JFrame object used for screen
   @return JFrame object
   */
   public JFrame getFrame()
   {
      return myApp;
   }
   
   /*
   switches between screens
   @param String value of screen to switched to
   */
   public void switchScreen(String whichScreen)
   {
      CardLayout layout = (CardLayout) myGenPanel.getLayout();
      layout.show(myGenPanel, whichScreen);
      
      if(whichScreen == GAME)
      {
         gScreen.requestFocusInWindow();
         
      }
      else if(whichScreen == TITLE)
      {
         tScreen.requestFocusInWindow();
      }
      
   }
   
   public static void main(String[] args)
   {
      ProjMoApp app = new ProjMoApp();
      app.setUpFrame();
      
   }
}